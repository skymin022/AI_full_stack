package _1066;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int num3 = sc.nextInt();
		
		if (num1 %2 == 0) {
			System.out.println(num1);
		}
		if (num2 %2 == 0) {
			System.out.println(num2);
		}
		if (num3 %2 == 0) {
			System.out.println(num3);
		}
		
		
	}
	
}
