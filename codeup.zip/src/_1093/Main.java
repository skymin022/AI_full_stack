package _1093;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//총 번호23
		int arr[] = new int[24];
		
		// n번 무작위
		int N = 0;
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
			System.out.print(arr[i]);
			
		}
		
		
		
	}
}
