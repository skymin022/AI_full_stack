package _1231;

import java.util.Scanner;

public class Main {

}