package _1160;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		switch (num) {
		case 1,3,5,7: System.out.println("oh my god"); break;

		default:  System.out.println("enjoy");
			break;
		}
		
	}
	
}