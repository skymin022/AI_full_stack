package _1164;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int class1 = 0;
		int time = 0;
		
		time = sc. nextInt();
		class1 = sc.nextInt();
		
		System.out.println(  + class1 );
		
	}
}