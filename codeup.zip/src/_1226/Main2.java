package _1226;

import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// 당첨 번호가 전부 일치할 경우
		// 
		
	
	}
}
